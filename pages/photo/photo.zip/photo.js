//index.js
//获取应用实例
const app = getApp()
//test
var animation = wx.createAnimation({
  transformOrigin: "50% 50%",
  duration: 1000,
  timingFunction: "ease",
  delay: 0
})
// var r=0;
var toggleTrueFalse = true;
var date = new Date();
var helloData = {
  name: 'WeChat'
}
Page({
  data: {
    // swiperBgcolor,
    helloData,
    rotateAngle:0,
    animationData: {},
    // count:1,
    motto: 'Hello World',
    currentTime: 'hello\n',
    frontText: '',
    timeLeft: '',
    nextClass: 'hello\n',
    classRoom: 'hello\n',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  
  //事件处理函数
  bindViewTap: function() {
    // alert(data-text)
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  onLoad: function () {
    // var r;
    setInterval(this.rotateAndScaleAThenBack, 1000);
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  onShow:function(){
    var animation = wx.createAnimation({
      duration: 1000,
      timingFunction: "ease",
    })

    this.animation = animation
    // animation.step()
   
    // animation.scale(2, 2).rotate(45).step();

    this.setData({
      animationData: animation.export()
    })

    setInterval(function () {
      // animation.opacity(0.5).step();
      // animation.translate(30).step();
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 1000)
  },
  rotateAndScale: function () {
    // 旋转同时放大
    this.animation.rotate(45).scale(2, 2).step()
    this.setData({
      animationData: animation.export()
    })
  },
  toggleText(){
    if(toggleTrueFalse){
      toggleTrueFalse = false;
      this.animation.scale(1.2,1.2).step();
    }
    else{
      toggleTrueFalse = true;
      this.animation.scale(1,1).step();
    }
  },
  rotateAndScaleAThenBack() {
    // this.animation.rotate(45).scale(2).step();
    // this.animation.rotate(0).scale(1).step();
    this.animation.skew(45).step();
    // if (toggleTrueFalse) {
    //   toggleTrueFalse = false;
    //   this.animation.scale(1.2, 1.2).step();
    // }
    // else {
    //   toggleTrueFalse = true;
    //   this.animation.scale(1, 1).step();
    // }
  },
  rotateThenScale: function () {
    // 先旋转后放大
    // this.rotateAngle += 45;
    r += 45;
    this.animation.rotate(r).step()
    // this.animation.rotate(90).step()
    // this.animation.rotate(135).step()
    // this.animation.scale(0.5, 2).rotate(45).step();
    // this.animation.scale(0.5, 2).rotate(90).step();
    this.setData({
      animationData: animation.export()
    })
  },
  rotateAndScaleThenTranslate: function () {
    // 先旋转同时放大，然后平移
    this.animation.rotate(45).scale(2, 2).step()
    this.animation.translate(100, 100).step({ duration: 1000 })
    this.setData({
      animationData: animation.export()
    })
  },
  //end animation

  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  
})
